from pathlib import Path
import json, hashlib, numpy as np
import campaign as c
R=Path(__file__).resolve().parent
C=[json.loads(l) for l in (R/'cycles.jsonl').read_text().splitlines()]
D=[json.loads(l) for l in (R/'decision_events.jsonl').read_text().splitlines()]
assert len(C)==len(D)==45
assert [c['cycle'] for c in C]==list(range(1,46))
assert [d['cycle'] for d in D]==list(range(1,46))
assert len(set(tuple((k,z['condition'][k]) for k in ['dataset','family','pilot','budget','noise','dropout','alpha']) for z in C))==45
for i,(d,r) in enumerate(zip(D,C)):
 assert d['condition']==r['condition']; assert d['previous_cycle']==(i or None)
 assert d['previous_winner']==(C[i-1]['winner'] if i else None)
 assert all(len(v['ids'])==len(set(v['ids'])) for v in r['scores'].values())
 assert all(len(v['ids'])==min(d['condition']['budget'], c.DS[d['condition']['dataset']]['d']-1) for v in r['scores'].values())
 assert all(0<=j<c.DS[d['condition']['dataset']]['d'] for v in r['scores'].values() for j in v['ids'])
for name, ds in c.DS.items():
 assert len(set(ds['train'])&set(ds['val']))==len(set(ds['train'])&set(ds['test']))==len(set(ds['val'])&set(ds['test']))==0
 assert len(ds['train'])+len(ds['val'])+len(ds['test'])==ds['n']
# Probe single standardization invariant on a nontrivial distribution.
rng=np.random.default_rng(17);X=rng.normal(12,4,(120,8));Xe=rng.normal(12,4,(40,8));x,te=c.transforms(X,Xe)
assert np.allclose(te, np.clip((Xe-X.mean(0))/np.maximum(X.std(0),1e-5),-10,10))
summary=json.loads((R/'SUMMARY.json').read_text())
assert sum(summary['wins'].values())==45
assert sum(summary['families'].values())==45
assert sum(summary['dataset_counts'].values())==45
print('PASS: 45 sequential decisions, matching causal lineage, unique settings, valid distinct subsets, fixed split and single normalization')
