"""POST-HOC audit: reproduce already-frozen final test, paired case bootstrap.
Not a new confirmatory test and not part of the 45 cycles."""
import campaign as c
import numpy as np,json
from pathlib import Path
from sklearn.linear_model import Ridge
r=json.loads((c.ROOT/'SUMMARY.json').read_text());out={}
for ix,(domain,receipt) in enumerate(r['final_test'].items()):
 cfg=receipt['frozen_final_config'];d=c.DS[domain];seed=123000+list(c.DS).index(domain)*99
 idx=np.random.default_rng(seed).permutation(d['train'])[:min(cfg['pilot'],len(d['train']))]
 trainx=d['x'][idx];trainy=d['y'][idx];te_x=d['x'][d['test']];te_y=d['y'][d['test']]
 x,xe=c.transforms(trainx,te_x); sels=c.methods(x,trainy,domain,min(cfg['budget'],d['d']-1),seed)
 preds={}
 for name,chosen in sels.items():
  _,rmod=c.fit_eval(x,trainy,xe,te_y,chosen,cfg['noise'],cfg['dropout'],seed+19,cfg['alpha'])
  # Correct single standardization from training pilot.
  pred=rmod.predict(xe[:,chosen]);preds[name]=pred
  got=float(np.sqrt(np.mean((pred-te_y)**2))); prior=receipt['test_once'].get(name)
  if prior is not None:assert abs(got-prior)<1e-10,(domain,name,got,prior)
 champion=receipt['chosen_method']; comparator='TARGET'
 sqc=np.mean((preds[champion]-te_y)**2,axis=1)
 sqt=np.mean((preds[comparator]-te_y)**2,axis=1)
 deltas=sqt-sqc
 rng=np.random.default_rng(5667+ix)
 choices=rng.integers(0,len(deltas),(3000,len(deltas)))
 boots=np.sqrt(np.mean(sqt[choices],axis=1))-np.sqrt(np.mean(sqc[choices],axis=1))
 diff=float(np.sqrt(sqt.mean())-np.sqrt(sqc.mean()))
 out[domain]={'chosen_method':champion,'control':comparator,'n_test':len(deltas),'test_rmse_gain_target_minus_chosen':diff,
             'bootstrap_paired_percentile_interval_95':np.quantile(boots,[.025,.975]).tolist(),
             'pct_bootstrap_champion_beats_target':float((boots>0).mean()),
             'absolute_gain_relative_to_target':float(diff/np.sqrt(sqt.mean())),'warning':'POST-HOC paired case bootstrap on a single heldout split, not a preregistered CI and may ignore spatial/temporal dependence'}
(c.ROOT/'AUDIT_TEST.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
