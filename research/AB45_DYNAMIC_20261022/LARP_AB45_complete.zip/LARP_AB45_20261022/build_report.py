import json,hashlib,sys,platform
from pathlib import Path
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent
s=json.loads((R/'SUMMARY.json').read_text());aud=json.loads((R/'AUDIT_TEST.json').read_text())
NAMES={'TARGET':'Greedy covariance-target','SHRINK':'Covariance shrinkage','RANK':'Individual supervised ranking','FPS':'Feature diversity (FPS)','RANDOM':'Random','SPATIAL_HYBRID':'Spatial-prior hybrid (digits only)'}
wins=[s['wins'][k] for k in NAMES];names=list(NAMES)
fig,ax=plt.subplots(figsize=(9.0,4.3));ax.barh([NAMES[a] for a in names[::-1]],wins[::-1]);ax.set_xlabel('Validation wins across 45 adaptive conditions');ax.set_title('Exploratory wins, shared validation: not independent trials');fig.tight_layout();fig.savefig(R/'wins45.png',dpi=165);plt.close(fig)
fig,ax=plt.subplots(figsize=(9,4.3));domains=list(s['final_test']);a=[s['final_test'][x]['test_once'][s['final_test'][x]['chosen_method']] for x in domains];b=[s['final_test'][x]['test_once']['TARGET'] for x in domains];rel=[(b[i]-a[i])/b[i]*100 for i in range(4)];ax.bar(domains,rel);ax.axhline(0,color='black',lw=.8);ax.set_ylabel('RMSE reduction versus target-greedy (%)');ax.set_title('One final heldout comparison per dataset (post-selection)');fig.tight_layout();fig.savefig(R/'test_gains.png',dpi=165);plt.close(fig)
summary='\n'.join(f"| {d} | {v['chosen_method']} | {v['test_once'][v['chosen_method']]:.5f} | {v['test_once']['TARGET']:.5f} | {100*(v['test_once']['TARGET']-v['test_once'][v['chosen_method']])/v['test_once']['TARGET']:+.2f}% |" for d,v in s['final_test'].items())
report=f'''# LARP | AB 3.2.1 | 45 ciclos de branching adaptativo, 22-10-2026

**DICTAMEN: 1/3; no demostrado 2/3.** Esta campaña **no implementó** la geometría MHU original de Scale3D ni el COSI histórico. Evaluó la *hipótesis transferible de selección de mediciones* con datos observados y presupuestos restringidos. No se declara novedad científica, arquitectura neuronal ni utilidad comercial validada.

## Pregunta y motivación

Tras varios estudios sintéticos y de imagen, se investigó si diversificación geométrica/estadística y estimación de covarianzas podían mejorar la selección restringida de observaciones en cuatro conjuntos de datos independientes de scikit-learn: Digits (1797 muestras, 64 píxeles), Wine (178, 13 variables), Breast Cancer (569, 30 variables) y Diabetes (442, 10 variables; regresión). El objetivo no es diagnóstico clínico. Fuentes incluidas en `sklearn.datasets`, con particiones train/valid/test deterministas por dataset.

La línea multisitio física Beijing Air Quality no se pudo materializar en el entorno; no hay prueba de redes físicas. Esto es un **pivot limitado** a adquisición de características estáticas con observación completa retrospectiva. Las perturbaciones y los costos no representan adquisiciones reales.

## Protocolo y branching REALMENTE hecho

45 decisiones preceden a sus experimentos respectivos, documentadas en `decision_events.jsonl`, y resultados en `cycles.jsonl`. Tras cada condición, se determinó la siguiente familia y dominio por ganador de VALIDACIÓN, margen, contadores de exploración y política explícita en `campaign.py::propose`. Las familias BASE, FEWSHOT, BUDGET, NOISE, DROPOUT, RIDGE_ALPHA y TRANSFER_DOMAIN se fijaron antes de ejecutar; **la secuencia y parámetros sí dependen de resultados anteriores**, pero no hubo 45 reformulaciones teóricas independientes. 22/45 condiciones pertenecen a TRANSFER_DOMAIN, interpretado como alternancia de cuatro datasets, no como experimentos externos independientes. El conjunto de validación fue reutilizado adaptativamente 45 veces. Los TEST de cada dominio permanecieron sin consultarse durante los 45 ciclos.

Métodos con presupuesto por condición: TARGET = selección greedy usando covarianza empírica y covarianza objetivo, SHRINK = covarianza regularizada (preexistente estadísticamente), RANK = scoring supervisado individual, FPS = selección de características descorrelacionadas (en Dígitos cobertura espacial auténtica de una retícula de píxeles), RANDOM, e híbrido espacial para Dígitos (núcleo gaussiano a priori). En otros datasets no se atribuye geometría a los índices de variables. Misma predicción Ridge y mismos ejemplos de entrenamiento por brazo.

**GANADORES VAL:** {json.dumps(s['wins'],ensure_ascii=False)}. Estadística descriptiva, sin significación global defendible dada la adaptación.

## TEST final: una sola evaluación congelada por dominio

Se eligió por dominio el brazo con RMSE de validación promedio más bajo entre sus últimas cinco condiciones. Se aplicaron cuatro configuraciones limpias idénticas por dominio a cada brazo, fijadas antes de abrir el test final. El estimando es RMSE de predicción usando las variables seleccionadas, no RMSE de campo físico ni coste monetario.

| Dataset | Brazo elegido | RMSE elegido | TARGET control | Reducción vs TARGET |
|---|---|---:|---:|---:|
{summary}

Bootstrap posterior emparejado del diferencial RMSE TARGET−elegido sobre casos del mismo TEST: Digits {aud['digits']['bootstrap_paired_percentile_interval_95']}; Breast {aud['breast']['bootstrap_paired_percentile_interval_95']}; Diabetes {aud['diabetes']['bootstrap_paired_percentile_interval_95']}. Estos intervalos son **diagnóstico post hoc**, no procedimientos preregistrados con garantías causales, y no representan replicación sobre nuevos dominios.

### Hallazgos a favor / en contra

- FAVOR: la elección contextual es plausible; SHRINK gana sobre TARGET por ~2.2% en Breast con incertidumbre elevada; FPS por descorrelación gana ~7.3% en Diabetes bajo configuración final. Ambas técnicas son conocidas y no confirman MHU.
- CONTRA: en Dígitos, SHRINK elegida con validación pierde ~1.36% ante TARGET en test; el híbrido espacial tampoco supera TARGET. En Wine TARGET sigue mejor. No hay superioridad universal, ninguna ventaja significativa de geometría MHU observada.
- Riesgo técnico: la primera campaña usó una **segunda normalización indebida** de evaluación. Se guardaron `INVALID_DOUBLE_SCALE_*`; tras descubrir el error se modificó `fit_eval`, se reiniciaron decisiones desde C01 y se volvió a ejecutar todo. Los resultados anteriores no sustentan inferencias.
- Riesgo estadístico: los cuatro tests finales se han abierto; ninguna repetición adicional sobre ellos sería confirmación. La escala de RMSE depende del número de clases y de la estandarización de la regresión: no promediar comparaciones absolutas entre dominios. Entrenar un Ridge de salida one-hot también difiere de optimizar exactitud de clasificación.

## Literatura que reduce posibilidad de novedad

- Von Kleist et al. (JMLR 2025) analizan evaluación de adquisición activa de variables y los problemas de cambio de distribución.
- Aronsson, Rahbar y Chehreghani (IJCAI 2026) unifican métodos de adquisición secuencial en una formulación POMDP.
- Valancius et al. (ICML 2024) estudian selección no greedy condicionada al conjunto adquirido.
- CAAF (Communications AI & Computing 2026) describe colocación de sensores dependiente de correlaciones y objetivos. Esta campaña no lo implementa ni lo supera.

## AB-DECIDE

**STOP la rama de feature selection estática como candidata a 2/3.** Continuar requiere una nueva clase de evidencia y una hipótesis específica irreducible a selección supervisada, shrinkage, métodos de diseño bayesiano o adquisición activa existentes. El usuario autorizó un máximo de 45: se ejecutaron 45, pero el número no fortalece su independencia estadística. Las variantes geométricas no merecen interpretación biológica ni el título MHU sin certificados espectrales y código original.

**Candidato futura rama (sin autorización automática de originalidad):** comunicaciones escasas y heterogeneidad funcional de verdaderos sensores distribuidos, con datos reales de paquetes y medidas, pérdidas por desconexión, coste de energía y comparación de métodos convencionales de diseño de redes. Antes de levantar experimentos, obtener observaciones reales y congelar la prueba.

## Reproducción y archivo

`OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python campaign.py 45`; `python verify.py`; `python audit.py`; `python build_report.py`. Dependencias: numpy, scipy, scikit-learn, matplotlib. Se preserva el historial fallido como archivo `INVALID_DOUBLE_SCALE_*` y no se reutilizan esos números en el análisis. Ver `MANIFEST_SHA256.json` para huellas y `README.md` para el alcance.
'''
(R/'DICTAMEN.md').write_text(report,encoding='utf-8')
(R/'PRIORS.md').write_text('''# Priors acumulativos LARP · AB45 (apéndice no calibrado)

| ID | Hipótesis | Evidencia favorable | Evidencia adversa | Estado y falsador |
|---|---|---|---|---|
| AB45-P01 | Un solo selector supervisado domina a los competidores estáticos | TARGET gana 15/45 validaciones y Wine test | SHRINK gana 11/45, FPS 9/45; Breast y Diabetes favorecen variantes | Universalidad REFUTADA en este banco; replicar en datasets nuevos |
| AB45-P02 | Regularizar covarianzas puede mejorar con pocos datos | SHRINK mejora RMSE de Breast (0.2510 vs .2568) | IC bootstrap posthoc del diferencial incluye 0; Digits deteriora | ABIERTO contextual; hacer prueba independiente y competidores elastic net |
| AB45-P03 | Diversidad de variables puede mejorar adquisición bajo presupuesto | Diabetes FPS 1.0831 vs TARGET 1.1684 | Variables no poseen geometría espacial; los efectos dependen de modelo y única partición | CONDITIONAL; comprobar estabilidad por replicación externa |
| AB45-P04 | La geometría MHU proporciona mejora específica en imagen | Ninguna evidencia directa | Híbrido espacial de Digits no gana test; ni generador ni certificados MHU implementados | NO PROBADO; no inferir de esta campaña |
| AB45-P05 | Una política de selección por validación nunca empeora respecto al control fijo | Breast y Diabetes favorables; Wine empata | Digits pierde tras selección; validación 45x adaptativa | FALSE como principio universal; probar meta-selección sobre dominios externos |

**Procedencia:** `campaign.py`, `cycles.jsonl` (45), `decision_events.jsonl` (45), `SUMMARY.json`, `AUDIT_TEST.json`; última fecha 2026-10-22. Ningún posterior bayesiano numérico calculado. Etiquetas: exploratorio sobre datos observados; no efecto causal ni novedad científica demostrada. Conserva todos los priors LARP precedentes.
''',encoding='utf-8')
(R/'NOTA_AB_M034.md').write_text('''# AB-M034 — Instrumentación coherente de la evaluación y selección adaptativa
Fecha 2026-10-22 | Estado PROPUESTA (no modifica AB 3.2.1).

**Anomalía real:** la primera ejecución de 45 decisiones transformó la entrada de evaluación dos veces frente a la de entrenamiento. El hecho de compartir este sesgo entre brazos no garantiza conservar su ranking. Se archivaron los archivos `INVALID_DOUBLE_SCALE_*`; se reparó la aplicación de transformaciones y se reejecutó desde C01 con decisiones recalculadas. La doble normalización afectaba en este experimento principalmente los elementos cerca del clipping: el cambio numérico fue pequeño, pero eso no legitima conservar los números antiguos.

**Propuesta:** para cada procedimiento que transforme información, verificar invariantemente que `transform(train)` y `transform(eval)` usan los mismos parámetros ajustados solo al train, y que ninguna transformación extra es aplicada sólo a evaluación; comprobar predicciones sobre un subconjunto idéntico de train y eval en una prueba de identidad.

**Hallazgo negativo relacionado:** una meta-política escogida por validación pierde en heldout Digits aunque gane en Breast y Diabetes. Añadir gate opcional para probar coste de selección, múltiples dominios y riesgo de selección sobre validación reutilizada. Esto amplía O2 y AB-M030, no demuestra mejor rendimiento de AB.

**Alcance:** los datos proceden de scikit-learn; 45 decisiones secuenciales sobre cuatro dominios no equivalen a 45 replicaciones. `verify.py` comprueba invariantes relevantes, pero no reemplaza una revisión científica externa.
''',encoding='utf-8')
(R/'README.md').write_text('''# LARP AB45 · Exploración adaptativa en cuatro datasets observados

- `DICTAMEN.md`: resultados, incertidumbre y dictamen 1/3.
- `campaign.py`: política explícita de decisión después de cada resultado de validación. 45 ciclos únicos.
- `decision_events.jsonl`: decisión y justificación escribiéndose **antes** de ejecutar cada ciclo.
- `cycles.jsonl`: error por brazo y subset de variables elegido.
- `SUMMARY.json`: 45 victorias de validación y 4 pruebas test finales, usadas una vez.
- `audit.py`/`AUDIT_TEST.json`: bootstrap post-hoc pareado, no confirmatorio.
- `verify.py`: invariantes de partición, cadena de decisiones, cuotas de features, normalización.
- `INVALID_DOUBLE_SCALE_*`: primera campaña exploratoria invalidada por doble transformación del evaluador.
- `PRIORS.md`, `NOTA_AB_M034.md`: registros acumulativos sin alterar protocolos anteriores.

Reproducir:
```
pip install numpy scipy scikit-learn matplotlib
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python campaign.py 45
OPENBLAS_NUM_THREADS=1 python verify.py
OPENBLAS_NUM_THREADS=1 python audit.py
python build_report.py
```
**Atención:** volver a ejecutar `campaign.py` reescribe el ledger validado y vuelve a abrir el test; mantener hashes originales antes de hacerlo. No afirmar confirmación nueva. Los datos proceden de `sklearn.datasets` instalado localmente; licencia/procedencia según paquete original.

Esto NO es Scale3D MHU ni COSI histórico, ni arquitectura neuronal, ni datos espaciales multisensor reales. Es una prueba de portabilidad conceptual que principalmente identifica límites a la originalidad.
''',encoding='utf-8')
files=[p for p in R.iterdir() if p.is_file() and p.name not in ('MANIFEST_SHA256.json','run.log')]
manifest={'date':'2026-10-22','source':'sklearn packaged data','hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)},'warnings':['Manifests match bytes; do not certify scientific validity','RUN may be regenerated only at risk of reusing test']}
(R/'MANIFEST_SHA256.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print('Report and manifest written',len(manifest['hashes']))
