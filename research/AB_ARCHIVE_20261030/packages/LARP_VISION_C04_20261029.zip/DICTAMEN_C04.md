# LARP-VISION — AB 3.2.1 C04, dictamen de clasificación

**Fecha:** 2026-10-29. **Estado:** RUN + auditado. **Nuevo ciclo experimental consumido:** 1 (C04). Del bloque de 20 autorizados: C02 (1) + C04 (1) = **2 ejecutados**, C03 de planificación no consume. **Saldo 18**. Ningún N1 nuevo no duplicado, N2=0, N3=0.

## A. Pregunta y unidad
¿La distribución de 160 lecturas escalares basada en cinco subtipos MHU espectrales finitos mejora la clasificación rostro/no rostro de fotografías con poco muestreo? Se analizaron 100 recortes de rostros y 100 recortes de fondo 25×25 provenientes de `skimage.data.lfw_subset`. 200 imágenes constituyen el máximo de unidades, **no** 32.400 observaciones independientes. Los cinco subtipos miden exactamente la misma intensidad; la propiedad MHU asintótica no está certificada.

## B–D. Hipótesis, diseño e instrumento
Comparadores: grid 16×10, Sobol scrambled, PoissonDisk con fill_space y selección dispersa, optimización espectral conjunta, optimización espectral individual, fases intertipo alteradas, azar, ANOVA top-160 píxeles supervisados con TRAIN, imagen completa de 625 píxeles (sin paridad de presupuesto). Cada opción tiene el mismo clasificador SVC RBF C=2, gamma=scale, excepto que los dos últimos usan distintas representaciones; las mediciones bilineales pueden combinar hasta cuatro píxeles originarios, por lo que `160 mediciones` no son exactamente `160 píxeles físicos` ni FLOPs iguales.

Entrenamiento siempre con imágenes limpias, 5-fold estratificado barajado con estados [13,29], seeds de geometría [4101,4109,4127]. Test clean, ruido Gaussiano sigma=.13 y oclusión negra 6×6. Bootstrap descriptivo por imagen; folds y seeds no aumentan la independencia. Entrada hash SHA256 `ce1ab433bd0a896d88a87e40efdf37d9e1ce98bbd3317b498da9f0a7b8e125d5`.

**Freeze real en GitHub antes de outcomes:** contrato C04 commit `cb110f2b81f1f767d1c2de8483dad1241958380a`, código fuente completo commit `4e4f4e1742015756b1216e7a0cd84f77c4a017ef`; git blob `979e61cdaacd2b30ca08a0968eb2e0f8d2dbebbf` verificado contra `git hash-object` local, SHA256 fuente `d57d21ce76d4513419fbf38df9ec62b771872a4d50f1856a3a16133b268b31ae`. Código ejecutado: el mismo archivo local. No CI, no main.

## E. Resultados
La corrida ejecutó 3 geometrías × 2 particiones CV × 5 folds × 9 modelos × 3 condiciones, guardando 32.400 predicciones por imagen y condición. SHA256 resultados crudos `ec917d39129004f56066836a1637c7d263099bc28c6f8880082303ee03474456`.

| Método | Clean % | Ruido % | Oclusión % |
|---|---:|---:|---:|
| grid | 97.25 | 97.00 | 96.00 |
| Sobol | 97.17 | 97.00 | 95.83 |
| PoissonDisk | 97.25 | 96.75 | 96.33 |
| MHU-proxy JOINT | 97.17 | 97.17 | 95.67 |
| MHU-proxy SUB | 97.17 | 97.17 | 95.83 |
| JOINT fases rotas | 97.00 | 96.58 | 95.75 |
| azar | 97.25 | 97.17 | 96.00 |
| ANOVA pixels 160 | 93.50 | 93.25 | 89.75 |
| píxeles completos 625 | 97.25 | 97.25 | 95.75 |

MHU-JOINT menos grid en clean = −0.083 puntos porcentuales (bootstrap descriptivo por 200 imágenes IC95 −0.25 a 0), menos Poisson −0.083 (mismo IC). JOINT menos SUB en clean = 0.000 puntos porcentuales (−0.25 a +0.25). En ruido JOINT menos Poisson +0.417 (−0.083 a +1.0); en oclusión −0.667 (−1.333 a −0.167). Los IC son descriptivos sin corrección múltiple, y su dependencia entre fotos puede ser mayor. Un efecto pequeño con suelo de error próximo a 2–4 % no basta para identificar geometría.

En escala geométrica, potencia baja-k de unión JOINT `4.60e−07`, SUB `1.49e−06`, retícula casi 0: el éxito en proxy espectral **no se convierte** en ventaja de clasificación. No computar 1/3 nuevo por el mismo patrón de proxy-performance gap ya archivado.

## F. Auditoría adversarial
1. **Techo de rendimiento ~97 % en casi todos los controles, incluso aleatorio:** insuficiente sensibilidad para diferenciar geometrías. Al tratarse de una tarea de rostro/fondo de 25×25, no representa clasificación compleja ni IA moderna.
2. El control ANOVA muestra que una regla *univariante* de píxeles aprendidos es peor en este dataset, **no** que MHU supere la selección adaptativa tipo TokenLearner ni un método aprendido competente de imágenes grandes.
3. Dispersión por geometric seeds y doble CV no son muestras humanas independientes; imágenes derivadas de un mismo corpus podrían compartir historia. Los 32.400 registros no son 32.400 imágenes.
4. 160 muestras bilineales combinan pixeles, mientras ANOVA elige 160 originales. No reclamar una reducción física 74.4% de acceso a fotodiodos ni gasto energético.
5. Ni Wei auténtico ni ViT entrenado, no benchmark multiespectral. No atribuir causalidad funcional MHU a las diferencias.
6. No se intentó inferir identidad, edad, sexo, demografía ni atributos sensibles.

## G. Confirmación
Clasificación nueva dentro de LARP, pero dataset cerrado de 200 imágenes LFW. No prueba externa confirmatoria, no primer 2/3. Necesario benchmark de múltiples fuentes, mayor dificultad, independiente de diseño, con sensores de modalidad diferente.

## H. Actualización de hipótesis
P-VIS10: patrones espaciales distintos conservan desempeño cercano al 97% con 160 medidas en esta tarea; la facilidad del endpoint impide discriminar mecanismos MHU. Prior de ventaja específica MHU NO aumenta. P-VIS11: el vínculo de potencia spectral baja-k con accuracy es débil en este rango y dataset; proxy-performance gap ya encontrado. P-VIS12: LFW no es el benchmark adecuado para potencia experimental; R5 STOP_LOCAL a reruns.

## I. Dictamen
Validez interna local razonable para exactitud condicionada al protocolo, validez externa baja; identificación de MHU específica NO; originalidad 2/3 NO; coste real de captación/despliegue no medido; código congelado verificablemente, reproducibilidad clon limpio todavía NO comprobada; raw en ZIP de conversación y no replicación externa. N1 nuevo 0, N2/N3 0.

## J. Decisión
**STOP_LOCAL C04** en LFW, no gastar 18 autorizaciones en repeticiones. **BRANCH** a dataset óptico multibanda independiente con 5+ canales físicos y observaciones de escenas distintas; preferir primera puerta de descarga legal/sha, registro + control auténtico de Wei, coste de medición y decodificador. Otra rama opcional: observaciones en CAVE 31 bandas con bandas visuales, pero permiso de redistribución no se presupone.

**CT2 nueva rama VISION:** 22→17(C01)→13(C02)→**11(C04)**. Escala ordinal, no probabilidad. Motivación de descenso: techo de rendimiento, ausencia de separación frente a grid/Poisson, límites de fuente. No cambia CT2 histórico de otras líneas LARP.

Fuentes: LFW skimage https://scikit-image.org/docs/stable/api/skimage.data.html#skimage.data.lfw_subset ; Jiao 2014 DOI 10.1103/PhysRevE.89.022721; Wei 2010 https://www.liyiwei.org/papers/noise-sig10/ ; CAVE https://cave.cs.columbia.edu/repository/Multispectral ; multi-band CC0 public candidate https://github.com/idt-fhac/odm_data_buergewald .
