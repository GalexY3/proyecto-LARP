# Local fresh-directory replay — C04
2026-10-29. Source SHA256 d57d21ce76d4513419fbf38df9ec62b771872a4d50f1856a3a16133b268b31ae; Git blob 979e61cdaacd2b30ca08a0968eb2e0f8d2dbebbf (same as source frozen before outcomes).
Copied source as sole custom code file into an empty temporary directory and ran Python there. 32,400 per-image observations, 21 geometry records and full summaries were **exactly identical** to the initial run after excluding the elapsed_sec field. This is independent process replay with same machine/libraries/data, **NOT** independent external replication, **NOT** GitHub clean clone verification, and not an additional AB scientific cycle. The run log was not retained because it contained only completion counters; replay command documented here.

```
tmp=$(mktemp -d)
cp vision_c04.py "$tmp/vision_c04.py"
python "$tmp/vision_c04.py" "$tmp/out"
# Compare parsed JSON to original, excluding elapsed_sec; compare every raw row.
```

Result: LOCAL_FRESH_DIR_REPLAY_IDENTICAL, original run 32400 rows, 21 geometry diagnostics, no mismatches, no repair. GitHub code availability verified; raw JSON remains in ZIP in conversation, not GitHub.
