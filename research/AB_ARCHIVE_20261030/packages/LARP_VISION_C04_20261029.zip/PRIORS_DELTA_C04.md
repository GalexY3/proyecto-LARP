# Priors específicos C04 · 2026-10-29

P-VIS10 (nuevo, exploratorio no grado N1): C04 muestra que cuadrícula, Sobol, Poisson y MHU-proxy se agrupan en ~97% aciertos en 200 imágenes binarias LFW con 160 mediciones. Falsador: datasets multi-clase difíciles independientes y control de sensores equivalente.

P-VIS11 (apoyo no independiente al prior P-VIS02): reducción espectral low-k en geometrías de 5 tipos no implica ganancia predictiva de clasificación; MHU-JOINT = 97.167%, SUB=97.167%, grid=97.25%. No duplicar en ledger 1/3.

P-VIS12 (nueva restricción instrumental, sin novedad): un benchmark muy sencillo produce techo de rendimiento y puede ocultar diferencias de sampler. Debe medirse dificultad antes de la inferencia y no seleccionar nuevo test después de explorar.

P-VIS13: ANOVA univariante no equivale a TokenLearner, ni selección de píxeles físicos comparable a bilineal; no tratar su peor desempeño como superioridad específica.

CT2 Vision: 13→11 (ordinal), no probabilidad. N1 nuevos 0, N2=0, N3=0. R5 STOP_LOCAL. Conserva todas las anteriores y fuentes.
