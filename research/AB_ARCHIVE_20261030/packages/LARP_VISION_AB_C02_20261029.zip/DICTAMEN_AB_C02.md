# LARP · Visión artificial · AB C02 — PIVOT hacia sensores RGB heterogéneos

**Fecha:** 29 de octubre de 2026. **Investigación:** LARP/MHU; continuación bajo autorización de 20 ciclos BRANCHING/PIVOT. **Estado C02:** una ejecución experimental de contraste controlado, exploratoria; cuatro seeds geométricas, cuatro imágenes TEST (solo dos nuevas respecto a C01), tres perturbaciones. **Nuevos N1:** 0 (no hay hallazgo positivo nuevo separable y validado); **N2/N3:** 0. **CT2 de línea VISIÓN:** C01 inicial 22 → C01 auditado 17 → C02 13 /100, juicio ordinal NO probabilístico. **R5:** STOP_LOCAL en imágenes RGB pequeñas; PIVOT pendiente de nuevos datos reales multiespectrales y ejecución rival publicado.

## Cadena de custodia y ejecución

Prerregistro escrito en la rama `research/ab-vision-mhu-20261029` de `GalexY3/proyecto-LARP`, commit previo a cualquier outcome C02 **`4ea4fbe98eebd562536e4f7bf937da45291bdceb`**, `research/AB_VISION_20261029/C02_PREREG.md`. Código local `vision_ab_c02.py`, SHA256 **`42b7bcef08ed0b02909ec4b95bbd3bbb46a338762ed011f1e8a64735b1e60729`**, consignado en GitHub antes de ejecución. Verificado después con `sha256sum` y de nuevo en `audit_c02.py`. Utiliza módulo original C01 `vision_ab_c01.py` con SHA256 **`5e47f6e63e98dd14655f8eeec0e8d826d97eb750fd24c099ea4b6aa3e50ea993`**. Resultado bruto `results_c02.json` SHA256 **`aaf9b227855ea05fff1351c0bf5d5fd91faf15e8c4622f4d7d9a6669dac3006e`**. El código fuente completo no se depositó como bytes en GitHub antes de ejecución, solo su hash, lo que limita el cumplimiento literal del requisito O3 de fuente GitHub congelada; no reinterpretar retroactivamente un hash como archivo fuente depositado. El código y JSON se archivan en el ZIP de esta sesión; **CLEAN_CLONE_NOT_VERIFIED**. Sin acceso al cubo espectral original de CAVE, sin ejecutar Wei.

## A — Pregunta y estimando

¿Optimizar conjuntamente la posición de cinco tipos de sensores *funcionalmente distintos* mejora la reconstrucción de fotografías RGB con 160 lecturas escalares respecto a optimizar individualmente cada subtipo, romper sus fases relativas o emplear distribuciones convencionales fuertes? Unidad real de generalización: imagen original; las cuatro seeds por imagen no constituyen cuatro réplicas externas. Outcome primario: diferencia media de MSE RGB en TEST, por imagen; condiciones separadas clean/drop20/noise03.

## B — Hipótesis competidoras

H1: JOINT mejora SUB y BROKEN debido a coordinación intertipo. H0: los espectros individuales y el decodificador controlan el error; no hay ganancia del acoplamiento. H2: regularidad espacial multicolor / blue noise convencional basta o gana. Otros mecanismos: sesgo del modelo RBF, campo espacial no periódico, fuerte correlación entre los cinco filtros (todos provienen de solo tres canales RGB).

## C — Diseño

Fotografías públicas incluidas con `skimage`: cuatro DEV (`astronaut`, `coffee`, `chelsea`, `rocket`), cuatro TEST (`retina`, `stereo_motorcycle`, `hubble_deep_field`, `immunohistochemistry`) y `colorwheel` separado por ser sintético. **Retina y stereo_motorcycle son las únicas fuentes TEST nuevas respecto a C01**; el resto tuvo exposición previa. Cropping central, 48×48 RGB. Cuatro seeds [2029,2039,2053,2063], 160 posiciones por geometría, cinco filtros de exactamente 32 observaciones cada uno: R, G, B, (R+G)/2, (G+B)/2. Estos filtros son mezclas lineales simuladas a partir de RGB, no cinco canales ópticos adquiridos de modo independiente, y no reproducciones certificadas del sistema de fotoreceptores aviar.

Seis brazos: `grid_balanced` (cuadrícula 16×10, asignación modular equilibrada); `poisson_multiclass_proxy` (disco de Poisson espaciado + selección farthest + asignación greedy maximin, **NO** el método auténtico Wei); `sobol_balanced` (Sobol scrambled + asignación maximin); `spectral_joint` (optimización conjunta banda baja); `spectral_sub` (solo subtipos); `joint_phase_broken` (trasladar independientemente cada subtipo desde joint, preservando exactamente su espectro individual). El mismo decodificador de mínimos cuadrados regularizados en RBF para todos: 8×8 bases gaussianas y tres canales, σ=.17, λ=.012. Condiciones clean / 20% lecturas perdidas / ruido σ=.03. Las lecturas son medidas de igual coste **por definición del piloto**, no costes físicos de sensor.

## D — Instrumentación y auditoría

648 filas de observaciones = 4 seeds × 6 métodos × 9 imágenes × 3 condiciones. Las cuotas [32,32,32,32,32] y validez geométrica se verifican en ejecución; una regresión determinista recupera RGB a partir de 160 escalares. Control de fase: máxima diferencia de potencia de subtipo JOINT vs BROKEN **inferior a 5×10⁻²⁰** en las cuatro seeds, lo que verifica la ablación geométrica matemática (no que preserve las ventajas de cobertura contra bordes). El nuevo PoissonDisk usa `fill_space` y cobertura espacial sin el fallo de concentración C01. No hay ajuste de hiperparámetros después de ver resultados C02; tampoco se demostró que sean óptimos para todos los métodos.

## E — Resultados

MSE RGB medio sobre las cuatro imágenes TEST, promediando cuatro seeds (menor mejor):

| Diseño | Clean | Drop 20% | Ruido .03 |
|---|---:|---:|---:|
| Poisson multiclase proxy (maximin) | **0,014835** | **0,016495** | **0,015077** |
| Cuadrícula equilibrada | 0,015167 | 0,017322 | 0,015369 |
| Sobol equilibrado | 0,015074 | 0,016608 | 0,015246 |
| Espectral por subtipos | 0,015454 | 0,016749 | 0,015705 |
| Espectral conjunto (MHU proxy finito) | 0,015477 | 0,016890 | 0,015777 |
| Conjunto con fases rotas | 0,015351 | 0,017131 | 0,015729 |

En clean, JOINT tiene error **4,33% mayor** que Poisson (delta = +0,000642); **0,145% mayor** que SUB (delta = +0,0000224) y **0,819% mayor** que BROKEN (delta = +0,0001257). JOINT supera a Poisson en **1/4** escenas y a SUB en **2/4** escenas. En las dos escenas realmente nuevas, JOINT también tiene error **3,52% mayor** que Poisson de media; gana a Poisson en solo una (retina). No interpretar una escena favorable como evidencia positiva independiente.

No se calculan p-valores confirmatorios, ya que el tamaño de muestra independiente es de solo cuatro escenas, de las que dos fueron usadas en C01 para otra tarea. No hay estimaciones robustas de eficiencia física, FLOPs de inferencia neuronal ni exactitud en clasificación de objetos.

## F — Auditoría adversarial

1. **Paridad informativa:** igualdad de 160 lecturas escalares y decodificador compartido; no paridad de coste total de diseño de patrón. La cuadrícula cuesta casi nada de generar, optimización espectral requiere ajuste computacional.
2. **Heterogeneidad incompleta:** cinco filtros pero rango máximo de información espectral **tres** porque todos son mezclas de RGB. No cinco bandas CAVE reales.
3. **Rival fuerte original no ejecutado:** Wei (2010) ofrece multicolor blue noise y es antecedente científico, pero `poisson_multiclass_proxy` no implementa fielmente su código.
4. **Ausencia de redes visuales aprendidas:** es demosaicing inverso con ridge, no CLIP/ViT/CNN, no inferencia de rendimiento cognitivo ni mejora de IA multimodal.
5. **Contaminación y n:** Hubble e inmunohistoquímica ya se utilizaron en C01 gris; las cuatro seeds se anidan en las imágenes.
6. **Ablación fase:** conserva espectro por subtipo (validación exacta) pero cambia posiciones en relación con los bordes, por lo que pueden variar simultáneamente condiciones no espectrales; no inferir causalidad de cross-phase exclusivamente en una cámara con soporte rectangular.
7. **Multiplicidad de exploración:** diferentes condiciones y diseños, sin corrección confirmatoria, e imagen retina favorable post hoc. El corpus no demuestra robustez universal.
8. **Coste y reproducibilidad:** original completo y JSON en archivos de conversación, source literal fuera de GitHub en el momento del run; no clonar y proclamar validación.

## G — Confirmación

SIN confirmación independiente externa. Se ha añadido una intervención nueva respecto a C01 (cinco sensores de diferentes funciones), pero solo dos fuentes TEST nunca empleadas antes en esa campaña y ninguna verdadera imagen con cinco bandas de espectro. El contraste verifica procedimientos y restricciones, no un nuevo principio de inteligencia artificial.

## H — Doble actualización

**P-VIS-06:** frente a controles competentes, optimización espectral conjunta en cinco filtros virtuales RGB no reduce MSE promedio; prior de ventaja visual general de MHU se debilita. **P-VIS-07:** preservar exactamente la potencia individual y romper fase no causa deterioro global de clean/noise en estas escenas; queda por evaluar con cinco modalidades independientes. **P-VIS-08:** asimetría fuerte entre retina (joint mejora a Poisson) y stereo_motorcycle (Poisson mejora a joint) indica heterogeneidad de textura y escena, pero n=2 nuevas sin evidencia generalizable. **P-VIS-09:** WACV 2023 propone aprendizaje conjunto de selección de banda, disposición de filtros y reconstrucción, antecedente más cercano a la variante sensorial; comparadores optimizadores *aprendidos* pendientes.

## I — Dictamen

- Validez interna para la tarea definida: experimento ejecutado con controles relevantes, paridad de lecturas y ablación verificada.
- Interpretación causal específica MHU: **NO identificada** (proxy finito, varios cambios geométricos, reconstrucción dependiente del interpolador).
- Eficiencia: **NO medida** en hardware ni en coste extremo a extremo.
- Alcance: **RGB de conveniencia, no sensor multiespectral**, datos observados con transformaciones controladas.
- Novedad: **N2/N3=0**; hallazgo favorable nuevo 1/3 tampoco. Resultado negativo de orientación de investigación.
- Reproducibilidad: raw/code/hash disponibles para inspección, **CLEAN_CLONE_NOT_VERIFIED**.

## J — Decisión R5

**STOP_LOCAL** a continuar con imágenes pequeñas RGB y patrones de este mismo generador. **PIVOT** condicionado a conseguir escenas espectrales medidas externamente (por ejemplo CAVE original, 32 escenas × 31 bandas), mosaico de cinco bandas espectrales reales, un método reconstrucción competente, el multicolor blue noise publicado por Wei ejecutado y una segunda arquitectura visual/token aprendida, con presupuesto completo comparado. No abrir ensayos A–J adicionales si esos instrumentos faltan; la autorización permite otras tareas, pero no obliga a fabricar 20 estudios ni a usar semillas como evidencia externa.

**CT2 de VISIÓN:** 22→17→13, ordinal según O4, descenso motivado por falta de ganancia de geometría bajo heterogeneidad visual RGB. **N1 nuevos 0, N2 0, N3 0**. Un ensayo C02 ejecutado bajo autorización de 20; saldo **19** para oportunidades con evidencia verdaderamente nueva, con advertencia de que fuente no estuvo depositada literalmente en GitHub antes del resultado (hash sí). Sin merge a main ni CI.

### Literatura documentada

- Jiao et al. (2014), avian multihyperuniformity, doi:10.1103/PhysRevE.89.022721
- Li-Yi Wei (2010), *Multi-Class Blue Noise Sampling*, SIGGRAPH, https://www.liyiwei.org/papers/noise-sig10/ ; código https://github.com/1iyiwei/noise/tree/master/RainbowNoise
- Li, Dai & Van Gool (2023), *Jointly Learning Band Selection and Filter Array Design for Hyperspectral Imaging*, WACV, https://openaccess.thecvf.com/content/WACV2023/html/Li_Jointly_Learning_Band_Selection_and_Filter_Array_Design_for_Hyperspectral_WACV_2023_paper.html
- Bian et al. (2021), *Generalized MSFA Engineering With Structural and Adaptive Nonlocal Demosaicing*, IEEE TIP, doi:10.1109/TIP.2021.3108913
- CAVE Columbia Database, 32 scenes × 31 bands, https://cave.cs.columbia.edu/repository/Multispectral
- EPFL RGB-NIR, 477 scenes, https://www.epfl.ch/labs/ivrl/research/downloads/rgb-nir-scene-dataset/
