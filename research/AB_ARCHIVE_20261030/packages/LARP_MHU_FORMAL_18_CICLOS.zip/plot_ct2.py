from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import json
root=Path(__file__).parent
traj={'date':'2026-10-29','type':'ordinal_subjective_not_probability','branches':{'vision_legacy':[{'step':'Inicio C01','ct2':22},{'step':'Fin C01','ct2':17},{'step':'Fin C02','ct2':13},{'step':'Fin C04','ct2':11}], 'universal_MHU':[{'step':'Math Cierre','ct2':1}],'conditional_multimodal':[{'step':'Math Inicio','ct2':24}]},'note':'New branches after D2 pivot are independent judgments, NOT a gain over 11 in same trajectory.'}
(root/'CT2_TRAYECTORIAS.json').write_text(json.dumps(traj,indent=2,ensure_ascii=False))
for name,limits in [('CT2_ESCALA_COMPLETA.png',(0,100)),('CT2_VISTA_AMPLIADA.png',(0,30))]:
 fig,ax=plt.subplots(figsize=(9.5,4.5));ax.plot([0,1,2,3],[22,17,13,11],marker='o',label='Rama Visión (histórica)')
 ax.axvline(3.5,linestyle='--',alpha=.6);ax.scatter([4],[1],marker='x',s=90,label='Afirmación universal (refutada)')
 ax.scatter([4.9],[24],marker='s',s=90,label='Rama condicionada a covarianza (nueva)')
 ax.set_xticks([0,1,2,3,4,4.9],['Inicio C01','C01','C02','C04','Universal','Condicionada'])
 ax.set_ylim(*limits);ax.set_ylabel('CT2 (ordinal 1–100; no probabilidad)')
 ax.set_title('LARP — trayectoria CT2 y ruptura entre ramas')
 ax.grid(alpha=.2);ax.legend(loc='upper left',fontsize=8);fig.tight_layout();fig.savefig(root/name,dpi=165);plt.close(fig)
