# LARP — VISION AB C01: muestreo visual con estructura multiclase espectral

**Fecha:** 2026-10-29. **Estado:** un ciclo A–J experimental ejecutado, con **un brazo Poisson-disk invalidado y reparado después de exposición**; resto de brazos sin reparación. **Tipo de evidencia:** exploratoria en imágenes observadas, no entrenamiento de una red visual. **Nuevos N1:** 0 (cuestión sustancialmente cubierta por campañas anteriores); **N2/N3:** 0. **CT2 VISION_C01:** 22 → 17 / 100, juicio ordinal de trayectoria hacia 2/3, no probabilidad. **R5:** STOP a nuevos barridos de este mismo benchmark; PIVOT condicionado a nueva fuente visual, algoritmos publicados comparables y validación neuronal.

## Resumen del dictamen

La optimización conjunta de cinco etiquetas espaciales reduce en la muestra la **energía estructural de baja frecuencia** de la unión con respecto a optimizar únicamente los cinco tipos (6,24×10⁻⁸ frente a 2,04×10⁻⁷). Esa reducción geométrica **no produce una ventaja reproducible en la reconstrucción de imágenes naturales**. En las nueve imágenes de evaluación, promediando seis semillas geométricas, el MSE de MHU_PROXY_JOINT fue **0,013214** (limpia), **0,015340** (30 % lecturas perdidas) y **0,016408** (ruido de lectura σ=0,08). Cuadrícula obtuvo 0,013028 / 0,014919 / 0,016479; Poisson-disk reparado obtuvo 0,013014 / 0,015174 / 0,016160; SUB_ONLY obtuvo 0,013226 / 0,014929 / 0,016532. MHU joint mejora a algunos controles, pero la hipótesis de ventaja específica de la coordinación conjunta no queda corroborada. Los resultados de Poisson corregido son post-exposición y, por ello, solo exploratorios.

La pregunta más prometedora cambia: **¿puede una geometría multihiperuniforme aportar eficiencia en la captación y combinación de canales sensoriales heterogéneos con distinto valor informativo, bajo restricciones materiales verificables, frente a métodos adaptativos publicados?** En C01 todos los tipos leen exactamente la misma intensidad gris: no se ha probado retina aviar funcional ni reconocimiento de objetos.

## A — Pregunta y contrato de verdad

La población de conveniencia son 13 imágenes preinstaladas en `skimage.data`: cuatro DEV (astronaut, coffee, chelsea, rocket) y nueve TEST (camera, coins, page, hubble_deep_field, immunohistochemistry, cell, brick, gravel, grass). No son una muestra aleatoria de imágenes naturales. La reutilización histórica de algunas imágenes por LARP no pudo excluirse; TEST es solo reservado **dentro de este script**, no una réplica externa. Todas se recortaron centradas, con reducción a 128×128 e interpolación anti-alias. La unidad para comparar diferencias es **imagen de origen**; las seis semillas sobre una misma fotografía no constituyen seis réplicas independientes.

El estimando descriptivo es la **diferencia de MSE por fotografía de origen** entre dos distribuciones bajo idénticas 160 lecturas y el mismo interpolador triangular lineal, con vecino más cercano fuera de la envolvente convexa. Esto mide fidelidad de reconstrucción, no precisión de clasificación ni latencia de una IA.

## B — Hipótesis y rivales

- **H_MHU_joint:** la optimización espectral conjunta produce menor error que optimizar los cinco subtipos por separado (`mhu_subtypes`) por coordinación de fases entre tipos.
- **H_coverage:** los resultados se explican por cobertura, densidad de muestra y borde, no por multihiperuniformidad.
- **H_baselines:** cuadrícula regular o muestreo blue-noise competente igualan o superan MHU en reconstrucción cuando el acceso informativo y el interpolador son iguales.
- **H_other:** las ventajas de MHU, si existen, requieren modalidades funcionales diferentes y covarianzas específicas que C01 no instrumenta.

Baselines ejecutados: retícula 16×10, Sobol scrambled, Poisson-disk SciPy **reparado post hoc**, CVT por tipo, optimización espectral solo de tipos. **No** se ejecutó código original de Li-Yi Wei SIGGRAPH 2010, TokenLearner, DynamicViT, ToMe, ViT ni el generador Scale3D nativo. Por tanto, ningún resultado derrota esos sistemas.

## C — Diseño

N=160, cinco tipos de 32 puntos, semillas `[1103,1109,1117,1123,1129,1151]`; perturbaciones: clean, 30 % sensores eliminados con máscara fijada por semilla, ruido gaussiano de lectura 0,08 truncado a [0,1]. Evaluación sobre 9 imágenes TEST, sin seleccionar imágenes favorables. Cuatro comparaciones principales contra SUB_ONLY, cuadrícula, Poisson-disk y CVT. Las semillas se reutilizan en todos los brazos de forma emparejada, pero las posiciones no coinciden.

La función espectral minimiza la potencia de Fourier en modos enteros 2D con 0<|k|²≤10, por tipo y, únicamente para JOINT, para la unión. Se añade repulsión geométrica local idéntica en JOINT y SUB_ONLY. Es un **proxy finito espectral optimizado sobre un toro**, sin certificado de hiperuniformidad asintótica; el dominio de fotografías no es periódico. La retícula hace cero el espectro en esos modos sin que ello la convierta en el supuesto mecanismo biológico investigado.

## D — Instrumentación, autenticidad y reparaciones

- Prerregistro en GitHub **antes de ejecutar**: `e50994d130af34207dfe4ceb14682f8253ceed93` en rama `research/ab-vision-mhu-20261029`.
- SHA256 del código congelado y ejecutado: `5e47f6e63e98dd14655f8eeec0e8d826d97eb750fd24c099ea4b6aa3e50ea993` (`vision_ab_c01.py`). Código disponible como archivo adjunto del informe; fuente completa todavía no verificada en clon limpio de GitHub.
- Archivo original íntegro: SHA256 `71cc4ca2b18360f83de5c61aaf2286fe25e6c19e76d14a30044bee6ca2cd9c18` (`results_original.json`).
- **ERRATA-01:** el primer brazo PoissonDisk utilizó `random(N)` con radio demasiado bajo; los 160 puntos llenaron solo parte de la imagen (distancia media al sensor más cercano ~0,1955). Todos sus MSE originales son **INVALID**. No compararlos ni citarlos como méritos de MHU. Errata versionada en GitHub `728c8b86e0ba3d814ef51abfaff3b75495ed0042`, **antes de ejecutar** la reparación, aunque después de conocer resultados originales.
- Código reparación SHA256 `85438d783f220761e1b5b8d2c678e2a77ee2787a2c7e5cbefac3b8d6d13c9570`, script `repair_poisson.py`. Usa `fill_space()` con radio 0,062 y quita puntos de densidad local máxima hasta N=160. Distancia media de cobertura reparada ~0,0322. Esta intervención, aunque documentada, **no transforma la comparación en confirmatoria**.
- Resultado reparado completo SHA256 `45c502b20277839476576c5868d348a66567193d2d012a778217734a15fbd5b8`.
- **CLEAN_CLONE_NOT_VERIFIED.** No se midieron FLOPs, coste energético real, latencia ni coste de fabricar sensores. Las imágenes preinstaladas no se redistribuyen.

## E — Resultados descriptivos

| Disposición | MSE normal | MSE al perder 30 % | MSE ruido 0,08 | Potencia media low-k de la unión |
|---|---:|---:|---:|---:|
| GRID | 0,013028 | **0,014919** | 0,016479 | 1,03×10⁻³² |
| PoissonDisk (reparado) | **0,013014** | 0,015174 | **0,016160** | 0,000984 |
| MHU_PROXY_JOINT | 0,013214 | 0,015340 | 0,016408 | 6,24×10⁻⁸ |
| MHU_PROXY_SUB_ONLY | 0,013226 | 0,014929 | 0,016532 | 2,04×10⁻⁷ |
| SOBOL | 0,013484 | 0,015447 | 0,016870 | 0,000827 |
| CVT_SUBTYPES | 0,015904 | 0,017546 | 0,019722 | 0,000161 |

JOINT – SUB_ONLY en MSE: normal -0,000012 (0,09 % relativo favorable), pérdida +0,000411 (**2,75 % peor**), ruido -0,000124 (0,75 % mejor); sobre nueve imágenes JOINT mejora 4, 4 y 4 respectivamente. JOINT – GRID: normal +0,000186 (1,43 % peor), pérdida +0,000421 (2,83 % peor), ruido -0,000071 (0,43 % mejor). Aunque JOINT reduce la energía low-k frente a SUB_ONLY, ambas ya la tienen cercana a cero y su error en imágenes es próximo. Esto corrobora la distinción entre optimización espectral y tarea funcional; no es descubrimiento original.

El contraste JOINT–GRID con 30% perdido tiene intervalo **bootstrap descriptivo** por nueve imágenes de [0,000029,0,000786]. No atribuir cobertura estadística confirmatoria: imágenes de conveniencia, múltiples comparaciones y reparación post-exposición. En normal, JOINT–SUB_ONLY intervalo [-0,000271,0,000247], compatible con ganancia o pérdida pequeña.

## F — Auditoría adversarial

1. **Definición:** MHU_PROXY no es MHU certificada ni muestra biológica real; baja potencia sobre 19 modos finitos no equivale a S(k)→0 bajo límite termodinámico.
2. **Rival independiente fuerte:** Wei (2010) ya propone distribuciones de ruido azul multiclase para sensores de imagen con clases y uniones; no ejecutado aquí. TokenLearner, DynamicViT y ToMe aprenden o fusionan tokens en modelos visuales: no se han derrotado.
3. **Reparación tras exposición:** PoissonDisk inicial inválido; reparar no legitima una nueva comparación confirmatoria.
4. **Canal funcional ausente:** los cinco tipos de sensores ven la misma señal gris, de modo que la heterogeneidad espectral/colores/gradientes de una retina no se probó. Este es el principal límite de mecanismo.
5. **Interpolador común no es mejor reconstrucción posible:** Delaunay + nearest igual para todos, pero la retícula podría usar interpolación bilineal natural y métodos adaptativos podrían aprender un decodificador. La comparación no es contra mejores pipelines para cada rival.
6. **Fuentes restringidas:** nueve imágenes de conveniencia, sin garantía de que las fuentes no fueran usadas antes; no probar independencia ni transportabilidad.
7. **Objetivo geométrico previsible:** la supresión low-k del método es consecuencia de penalizar expresamente ese objetivo, no prueba independiente de utilidad.
8. **Presupuesto:** 160 lecturas equiparadas; coste de generar patrón, entrenar y ejecutar modelo o extraer saliencia no medido. Comparación económica/energética no posible.
9. **Fronteras:** bordes no periódicos, escalas de imagen y detalles finos; no se probó clasificación, segmentación, restauración neuronal, visión multimodal ni OOD categórico.

## G — Confirmación

No existe replicación externa; TEST se reservó en este programa pero podría solaparse con fuentes utilizadas previamente en LARP. Los seis seeds son replicación del diseño geométrico, **no** seis nuevos datasets. Estado `EXPLORATORY_COMPUTATIONAL` más `POST_HOC_REPAIR` para Poisson, no `EXTERNAL_IDENTIFIED_EFFECT`. Se evita p-valor confirmatorio y conteo de N1 duplicado.

## H — Actualización de priors

- P-VIS01: la coordinación MHU conjunta, aislada de la calidad individual y con canal monomodal, no mejora sistemáticamente la reconstrucción; **apoyo descriptivo** a nula, coherente con hallazgos previos de LARP.
- P-VIS02: la supresión espectral finita no basta para ganar a baselines de cobertura en fotografías naturales; **evidencia descriptiva adicional**, antecedente técnico muy fuerte.
- P-VIS03: la oportunidad plausible depende de canales diferentes, coste y aprendizaje downstream; **hipótesis NO VALIDADA**, no actualizada positivamente por C01.

No sobrescribir los priors canónicos; añadir apéndice vinculado al proyecto con parentesco con `LARP-1-005` y AB08.

## I — Dictamen por dimensiones

| Dimensión | Dictamen |
|---|---|
| Resultado geométrico | Optimización espectral conjunta operativa sobre banda finita; aporte instrumental no novedoso. |
| Validez de reconstrucción | Comparación local útil, sin ganancia robusta del mecanismo frente a cuadrícula/Poisson. |
| Validez interna | Buena paridad de lecturas/interpolador; un control inválido reparado post-exposición y esfuerzos de generación desiguales. |
| Generalización | Muy limitada por fuentes de conveniencia, resolución y ausencia de tareas de reconocimiento. |
| Valor para LARP | Un resultado negativo discriminante: el patrón solo no explica mejora visual general. |
| Novedad científica | **2/3 NO ACREDITADO**; ya existe SIGGRAPH 2010 y líneas de aprendizaje de tokens. |
| Reproducibilidad | Código, JSON, hashes disponibles localmente; clon GitHub íntegro **no verificado**. |

**CT2 ordinal nueva rama VISION_C01: 22 → 17**, descenso motivado por falta de ganancia respecto a rivales fuertes, baja originalidad, falta de visión neuronal y dependencia de patrones optimizados sobre la métrica espectral. No cambia CT2 de ramas históricas de LARP. **N1 nuevo: 0** por parentesco directo con `LARP-1-005`.

## J — AB-DECIDE

**STOP_LOCAL** para repetir reconstrucción de imágenes pequeñas en estas mismas fuentes y geometrías. **PIVOT condicional** hacia modalidad real y reconocimiento visual: generar diseños bidimensionales con algoritmo MHU certificado a escala finita, ejecutar el auténtico método Wei o baseline equiparable, seleccionar **dataset externo verdaderamente nuevo** (cientos/miles de imágenes, licencia legal), medir una tarea downstream real (clasificación o segmentación con encoder preentrenado y presupuestos igualados) y un objetivo robusto relacionado con canales **funcionalmente heterogéneos**. Intervención falsadora: romper solo la coordinación intertipo conservando espectros por tipo y presupuesto, medir si baja el rendimiento sobre datos no utilizados en la optimización. R5 exige esto antes de otro ciclo. Sin esas condiciones, cerrar, no rellenar cupo.

## Fuentes y antecedentes verificables

- Jiao et al. (2014): DOI `10.1103/PhysRevE.89.022721`, multihiperuniformidad en cinco conos de gallina. https://doi.org/10.1103/PhysRevE.89.022721
- Li-Yi Wei (2010), *Multi-Class Blue Noise Sampling*, SIGGRAPH. https://www.liyiwei.org/papers/noise-sig10/
- Ryoo et al. (2021), *TokenLearner*. https://arxiv.org/abs/2106.11297
- Rao et al. (2021), *DynamicViT*, NeurIPS. https://proceedings.neurips.cc/paper/2021/hash/747d3443e319a22747fbb873e8b2f9-Abstract.html
- Bolya et al. (2023), *Token Merging: Your ViT but Faster*, ICLR. https://arxiv.org/abs/2210.09461
- Evidencia anterior LARP: `docs/AB06_REALDATA_20261022/DICTAMEN_AB06.md`; `docs/AB08_CROSSPHASE_20261022/DICTAMEN_AB08.md`; `research/AB30_DISCOVERY_20261022/reports/DICTAMEN.md`; `research/FINDINGS_1_3/LEDGER.json`.

## Solicitud de siguiente bloque (condicional)

Si se obtiene un benchmark visual independiente adecuado y un comparador Wei/visual-token realmente ejecutable, se justifica un paquete de 20 ciclos BRANCHING AB de nueva evidencia (control de fuente, geometría, heterogeneidad, ablación, reconocimiento, costes, replicación); **no activarlos ni contarlos mientras falten esas condiciones**. **SOLICITO BRANCHING 20 CICLOS CONDICIONADOS A NUEVA EVIDENCIA.**
