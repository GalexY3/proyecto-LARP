# LARP / visión — apéndice de priors prospectivos y actualización 2026-10-29

No sustituye `docs/02_PRIORS_LARP.md` ni `research/FINDINGS_1_3/LEDGER.json` del repositorio principal. Resultados nuevos 1/3: 0 por duplicación material con `LARP-1-005` y AB08.

| ID | Prior previo | Evidencia C01 | Estado posterior | Falsador externo |
|---|---|---|---|---|
| P-VIS01 | Coordinación espectral intertipo podría mejorar reconstrucción frente a subtipos aislados | JOINT - SUB_ONLY: −0,000012 normal, +0,000411 30 % dropout, −0,000124 ruido; n=9 imágenes, 6 seeds | Hipótesis favorecida **no**; probable efecto específico pequeño o nulo en captación gris; no probabilidad numérica | Una mejora reproducible en corpus independiente con misma señal, presupuesto y baseline Wei |
| P-VIS02 | Reducción de S(k) a baja frecuencia puede reducir errores de imagen | JOINT baja espectro unión 3× frente SUB_ONLY, pero no mejora de manera robusta el MSE | Control de Goodhart geométrico: **reforzar** la separación proxy y outcome; antecedente conocido | Ventaja de error de imagen contra retícula/blue-noise fuerte manteniendo cobertura y costes |
| P-VIS03 | Modalidades visuales heterogéneas podrían beneficiarse de coordinación MHU | C01 carece de modalidades diferentes; sin información discriminante | **NO_VALIDADO; NO ACTUALIZAR A FAVOR** | Implementar cinco modalidades independientes, ablación de fases, benchmark visual externo |
| P-VIS04 | Una distribución optimizada puede dominar una fuerte blue-noise | PoissonDisk original INVALID por concentración espacial; reparación post-exposición y empate/aparente ligera victoria Poisson en clean/ruido | **Evidencia metodológica contra controles débiles**; no acreditación novedosa | Implementación original Wei 2010 con misma escala y coste, en test externo |

Control metodológico: la evidencia favorable a CVT débil no justifica universalidad; el mismo conjunto de imágenes se usó para evaluar todos los rivales; semillas no equivalen a fotografías adicionales.
