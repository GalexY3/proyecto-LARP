from pathlib import Path
import numpy as np, matplotlib.pyplot as plt
p=Path(__file__).resolve().parent
series=[('Fases multiclase',24,24),('Cobertura LOCAL/CVT',17,17),('Muestreo y ruido',15,15),('Marcas y objetivos',21,21)]
for full in [True,False]:
 fig,ax=plt.subplots(figsize=(8.6,4.4));
 for title,lo,hi in series:ax.plot([0,1],[lo,hi],marker='o',label=title)
 ax.set_xticks([0,1],['Prerregistro','Tras auditoría']);ax.set_xlim(-.16,1.16)
 if full:ax.set_ylim(0,100);ax.set_ylabel('CT2 (escala ordinal 0–100)');fn='CT2_ESCALA_0_100.png'
 else:ax.set_ylim(10,30);ax.set_ylabel('CT2 (vista ampliada 10–30)');fn='CT2_VISTA_AMPLIADA.png'
 ax.set_title('LARP: ramas matemáticas, sin cambios artificiales de CT2');ax.grid(True,alpha=.22);ax.legend(fontsize=8,loc='upper right');fig.tight_layout();fig.savefig(p/fn,dpi=165);plt.close(fig)
# A precise 1D counterexample: geometry vs finite modes.
fig,ax=plt.subplots(figsize=(9.2,2.6));n=8;epsilon=.017;p0=np.arange(n)/n;p1=(p0+(-1.)**np.arange(n)*epsilon)%1
ax.scatter(p0,np.ones(n),s=70,label='Retícula uniforme')
ax.scatter(p1,np.zeros(n),s=70,label='Alternancia ±0,017')
ax.set_yticks([0,1],['Perturbada','Regular']);ax.set_xlim(-.035,1.04);ax.set_xlabel('Posición normalizada en el círculo');ax.set_title('Contraejemplo S09: baja frecuencia idéntica, peor hueco máximo');ax.grid(axis='x',alpha=.22);fig.tight_layout();fig.savefig(p/'S09_CONTRAEJEMPLO.png',dpi=165);plt.close(fig)
print('plots generated')
